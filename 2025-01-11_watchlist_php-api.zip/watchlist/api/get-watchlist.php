<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

error_log("Test log entry at " . date('Y-m-d H:i:s'));

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

require_once('../config/config.php');
require_once('../config/database.php');

$polygonApiKey = 'DdNQoI7RBrzFyS9BDamUOgRMp_OAW6LH';

$stocksPerPage = 5;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $stocksPerPage;

$totalQuery = 'SELECT COUNT(*) as total FROM watchlist';
$totalResult = $conn->query($totalQuery);

if (!$totalResult) {
    error_log("Failed to retrieve total records. Error: " . $conn->error);
    die(json_encode(['error' => 'Database query error']));
}

$totalRow = $totalResult->fetch_assoc();
$totalRecords = $totalRow['total'];
$totalPages = ceil($totalRecords / $stocksPerPage);

$query = "SELECT id, symbol, note FROM watchlist LIMIT $offset, $stocksPerPage";
$result = $conn->query($query);

if (!$result) {
    error_log("Failed to fetch stocks. Error: " . $conn->error);
    die(json_encode(['error' => 'Database query error']));
}

$stocks = [];

while ($row = $result->fetch_assoc()) {
    $symbol = $row['symbol'];

    // Fetch fresh price data from the API
    $priceApiUrl = "https://api.polygon.io/v2/aggs/ticker/{$symbol}/prev?apiKey={$polygonApiKey}";
    $priceResponse = @file_get_contents($priceApiUrl);

    if ($priceResponse) {
        $priceData = json_decode($priceResponse, true);
        $price = $priceData['results'][0]['c'] ?? 'N/A';
    } else {
        error_log("Failed to fetch price data for symbol: $symbol. Error: " . json_encode(error_get_last()));
        $price = 'N/A';
    }

    // Fetch company name data from the API
    $companyApiUrl = "https://api.polygon.io/v1/meta/symbols/{$symbol}/company?apiKey={$polygonApiKey}";
    $companyResponse = @file_get_contents($companyApiUrl);

    if ($companyResponse) {
        $companyData = json_decode($companyResponse, true);
        $companyName = $companyData['name'] ?? $symbol; // Default to symbol if name is unavailable
    } else {
        error_log("Failed to fetch company name for symbol: $symbol. Error: " . json_encode(error_get_last()));
        $companyName = $symbol; // Default to symbol if API call fails
    }

    $stocks[] = [
        'id' => $row['id'],
        'symbol' => $symbol,
        'note' => $row['note'],
        'price' => number_format((float)$price, 2, '.', ''),
        'companyName' => $companyName,
    ];
}

// Return JSON response
echo json_encode([
    'stocks' => $stocks,
    'totalPages' => $totalPages,
]);

$conn->close();
?>
